"""Extrae las fotos originales incrustadas. Python 3, sin dependencias externas."""
from pathlib import Path
import re,json,base64,hashlib

root=Path(__file__).resolve().parent
html=(root/'Viena-II-Calles-Cafes-Restaurantes.html').read_text(encoding='utf-8')
data=json.loads((root/'Viena-II-Lugares-y-fuentes.json').read_text(encoding='utf-8'))
photos={p['id']:p for p in data['photos']}
folder=root/'Fotografias';folder.mkdir(exist_ok=True)
found=set()
for m in re.finditer(r'data-photo="([^"]+)"[^>]*>\s*<img src="data:([^;]+);base64,([^"]+)"',html):
    pid=m[1];photo=photos[pid];content=base64.b64decode(m[3],validate=True)
    assert hashlib.sha256(content).hexdigest()==photo['sha256'],f'Integridad incorrecta: {pid}'
    target=folder/(pid+'-'+Path(photo['localFile']).name)
    if target.exists():
        assert hashlib.sha256(target.read_bytes()).hexdigest()==photo['sha256'],f'Ya existe otro archivo: {target.name}'
    else:
        target.write_bytes(content)
    found.add(pid)
assert found==set(photos),'Faltan fotografías en el HTML'
print(f'{len(found)} fotografías verificadas en {folder}')
